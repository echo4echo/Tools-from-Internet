﻿using System.Windows.Forms;

namespace CrashReporterDotNET
{
    internal partial class ProgressDialog : Form
    {
        public ProgressDialog()
        {
            InitializeComponent();
        }
    }
}