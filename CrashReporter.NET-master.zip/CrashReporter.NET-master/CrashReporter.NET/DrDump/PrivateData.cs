﻿namespace CrashReporterDotNET.DrDump
{
    class PrivateData
    {
        public string UserEmail { get; set; }
        public string UserMessage { get; set; }
        public string DeveloperMessage { get; set; }
        public byte[] Screenshot { get; set; }
    }
}